-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 03, 2014 at 09:04 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `editionbakame`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `user_id` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `username`, `password`) VALUES
(1, 'edition', 'editionbakame');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `inventory_id` int(11) NOT NULL AUTO_INCREMENT,
  `book_title` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `cover` varchar(100) NOT NULL,
  `detaills` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `copy` int(11) NOT NULL,
  `time` varchar(11) NOT NULL,
  PRIMARY KEY (`inventory_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`inventory_id`, `book_title`, `author`, `price`, `cover`, `detaills`, `description`, `copy`, `time`) VALUES
(3, 'UBUVANGANZO', 'kees', '4545', 'book-cover.jpg', 'IT224-FTP SERVICE2.pdf', 'The book is a valuable source of knowledge that consists of infinite benefits. It transports us into different worlds and cultures, as well as, it informs us about ancient civilizations and lore. In addition, it helps us to learn about new technologies and literature. It allows speaking languages fluently and to communicate spontaneously. Therefore, the book can be faithful friend and the nearest into us which can guide us to how to behave in our practical life.', 91, '07/08/2014'),
(4, 'THE MAGIC FORMULA', 'mathew', '2000', '6aba3eb5378ec524fb3c619be4a2811f.jpg', 'Guinness.pdf', 'The book is a valuable source of knowledge that consists of infinite benefits. It transports us into different worlds and cultures, as well as, it informs us about ancient civilizations and lore. In addition, it helps us to learn about new technologies and literature. It allows speaking languages fluently and to communicate spontaneously. Therefore, the book can be faithful friend and the nearest into us which can guide us to how to behave in our practical life.', 83, '07/08/2014'),
(5, 'INDYO YUZUYE', 'kamichi', '780', 'SBS-Cover.jpg', 'reference_en.pdf', 'The book is a valuable source of knowledge that consists of infinite benefits. It transports us into different worlds and cultures, as well as, it informs us about ancient civilizations and lore. In addition, it helps us to learn about new technologies and literature. It allows speaking languages fluently and to communicate spontaneously. Therefore, the book can be faithful friend and the nearest into us which can guide us to how to behave in our practical life.', 95, '07/10/2014'),
(6, 'AMABARUWA YURUKUNDO', 'GAMMY', '3900', 'Energy_book_cover_for_InsanaMedia_design_samples.jpg', 'IT224-FTP SERVICE2.pdf', 'The book is a valuable source of knowledge that consists of infinite benefits. It transports us into different worlds and cultures, as well as, it informs us about ancient civilizations and lore. In addition, it helps us to learn about new technologies and literature. It allows speaking languages fluently and to communicate spontaneously. Therefore, the book can be faithful friend and the nearest into us which can guide us to how to behave in our practical life.', 96, '09/14/2010'),
(8, 'BWIZA BWA MASHIRA', 'bertrand', '4500', 'Life_Lessons_Book_Cover.jpg', 'IT224-Postfix Mail Server.pdf', 'The book is a valuable source of knowledge that consists of infinite benefits. It transports us into different worlds and cultures, as well as, it informs us about ancient civilizations and lore. In addition, it helps us to learn about new technologies and literature. It allows speaking languages fluently and to communicate spontaneously. Therefore, the book can be faithful friend and the nearest into us which can guide us to how to behave in our practical life.', 100, '07/21/2014'),
(9, 'URUKUNDO MU CYARO', 'deo Mg', '3200', 'url.jpg', 'it-service-datasheet.pdf', 'The book is a valuable source of knowledge that consists of infinite benefits. It transports us into different worlds and cultures, as well as, it informs us about ancient civilizations and lore. In addition, it helps us to learn about new technologies and literature. It allows speaking languages fluently and to communicate spontaneously. Therefore, the book can be faithful friend and the nearest into us which can guide us to how to behave in our practical life.', 98, '07/22/2014'),
(11, 'MBAYE UWANDE', 'JOLIE Justine', '4700', 'live-and-let-die-book-cover.jpg', 'ntwk_dnsdhcp_lx.pdf', 'The book is a valuable source of knowledge that consists of infinite benefits. It transports us into different worlds and cultures, as well as, it informs us about ancient civilizations and lore. In addition, it helps us to learn about new technologies and literature. It allows speaking languages fluently and to communicate spontaneously. Therefore, the book can be faithful friend and the nearest into us which can guide us to how to behave in our practical life.', 96, '05/01/2012'),
(13, 'NKUNDA GUSOMA', 'El Placide', '792', 'book_cover_for_novel_by_apiphile-d4klwbc.png', 'BACKTRACK_CUDA_v2.0.pdf', 'The book is a valuable source of knowledge that consists of infinite benefits. It transports us into different worlds and cultures, as well as, it informs us about ancient civilizations and lore. In addition, it helps us to learn about new technologies and literature. It allows speaking languages fluently and to communicate spontaneously. Therefore, the book can be faithful friend and the nearest into us which can guide us to how to behave in our practical life.', 89, '03/11/2012'),
(14, 'TYAZA UBWENGE', 'HIRWA FELIX', '4500', 'book-cover-rhyme-v1-450w-front.jpg', 'di-1018.pdf', 'The book is a valuable source of knowledge that consists of infinite benefits. It transports us into different worlds and cultures, as well as, it informs us about ancient civilizations and lore. In addition, it helps us to learn about new technologies and literature. It allows speaking languages fluently and to communicate spontaneously. Therefore, the book can be faithful friend and the nearest into us which can guide us to how to behave in our practical life.', 100, '07/20/2014'),
(15, 'NGUNDA', 'ASHER HABINSHUTI', '1000', '01-love-story-game.jpg', 'reference_en.pdf', 'The book is a valuable source of knowledge that consists of infinite benefits. It transports us into different worlds and cultures, as well as, it informs us about ancient civilizations and lore. In addition, it helps us to learn about new technologies and literature. It allows speaking languages fluently and to communicate spontaneously. Therefore, the book can be faithful friend and the nearest into us which can guide us to how to behave in our practical life.', 100, '01/31/2012'),
(16, 'UBURYARYA BWA BAKAME', 'FABRICE', '3700', '3D-printed-book-cover-of-On-Such-a-Full-Sea-by-Chang-rae-Lee-created-with-a-MakerBot_dezeen_3.jpg', 'IT224-FTP SERVICE2.pdf', 'The book is a valuable source of knowledge that consists of infinite benefits. It transports us into different worlds and cultures, as well as, it informs us about ancient civilizations and lore. In addition, it helps us to learn about new technologies and literature. It allows speaking languages fluently and to communicate spontaneously. Therefore, the book can be faithful friend and the nearest into us which can guide us to how to behave in our practical life.', 100, '07/01/2014'),
(17, 'KANYANA', 'SANDRINE KARIGIRWA', '1200', '6a00d83451bcff69e2011572161038970b.jpg', 'IT224-FTP SERVICE2.pdf', 'The book is a valuable source of knowledge that consists of infinite benefits. It transports us into different worlds and cultures, as well as, it informs us about ancient civilizations and lore. In addition, it helps us to learn about new technologies and literature. It allows speaking languages fluently and to communicate spontaneously. Therefore, the book can be faithful friend and the nearest into us which can guide us to how to behave in our practical life.', 116, '02/12/2013'),
(18, 'AKARO GAHIRE', 'ADELINE ISIMBI', '2500', 'hh.jpg', 'IT224-Postfix Mail Server.pdf', 'The book is a valuable source of knowledge that consists of infinite benefits. It transports us into different worlds and cultures, as well as, it informs us about ancient civilizations and lore. In addition, it helps us to learn about new technologies and literature. It allows speaking languages fluently and to communicate spontaneously. Therefore, the book can be faithful friend and the nearest into us which can guide us to how to behave in our practical life.', 150, '09/20/2011'),
(19, 'YIFUJE UBWIZA', 'UMUHOZA ROSINE', '630', 'BookCovers1.gif', 'application.pdf', 'The book is a valuable source of knowledge that consists of infinite benefits. It transports us into different worlds and cultures, as well as, it informs us about ancient civilizations and lore. In addition, it helps us to learn about new technologies and literature. It allows speaking languages fluently and to communicate spontaneously. Therefore, the book can be faithful friend and the nearest into us which can guide us to how to behave in our practical life.', 44, '01/10/2011'),
(20, 'TAMBOURS POUR LA PAIX', 'ALINE KWIZERA', '530', 'book_cover_design.jpg', 'HackYourFriend.pdf', 'The book is a valuable source of knowledge that consists of infinite benefits. It transports us into different worlds and cultures, as well as, it informs us about ancient civilizations and lore. In addition, it helps us to learn about new technologies and literature. It allows speaking languages fluently and to communicate spontaneously. Therefore, the book can be faithful friend and the nearest into us which can guide us to how to behave in our practical life.', 83, '11/16/2010'),
(21, 'UBUTUNGUTUNGU', 'Dieudonne SHUMBUSHO', '1852', 'book_cover_for_novel_by_apiphile-d4klwbc.png', 'Packtpub.Building.Telephony.Systems.with.OpenSIPS.1.6.Jan.2010.pdf', 'The book is a valuable source of knowledge that consists of infinite benefits. It transports us into different worlds and cultures, as well as, it informs us about ancient civilizations and lore. In addition, it helps us to learn about new technologies and literature. It allows speaking languages fluently and to communicate spontaneously. Therefore, the book can be faithful friend and the nearest into us which can guide us to how to behave in our practical life.', 81, '04/05/2011');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `user_id` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `id_number` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`user_id`, `username`, `password`, `firstname`, `lastname`, `id_number`, `address`, `email`, `phone`) VALUES
(1, 'el placide', '123456789', 'MAHIRWE', 'Aime Placide', '1199580104570074', 'GATSATA', 'mapla2007@gmail.com', '0722705494'),
(2, 'el fab', '123456789', 'MUTSINZI', 'FABRICE', '1199680000973034', 'GISOZI', 'fab@gmail.com', '0788963685');

-- --------------------------------------------------------

--
-- Table structure for table `sold_books`
--

CREATE TABLE IF NOT EXISTS `sold_books` (
  `sold_id` int(11) NOT NULL AUTO_INCREMENT,
  `book` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `customer` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`sold_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `sold_books`
--

INSERT INTO `sold_books` (`sold_id`, `book`, `qty`, `customer`, `date`) VALUES
(3, 6, 2, 2, 1409382130),
(20, 6, 1, 1, 1409468157),
(23, 19, 1, 2, 1409468354),
(24, 5, 1, 2, 1409468354),
(26, 4, 5, 1, 1409579103),
(27, 3, 1, 1, 1409582789),
(28, 5, 1, 1, 1409582789),
(29, 19, 1, 2, 1409582872),
(30, 4, 1, 2, 1409582872),
(31, 5, 1, 1, 1409679754),
(32, 4, 1, 1, 1409679754);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
